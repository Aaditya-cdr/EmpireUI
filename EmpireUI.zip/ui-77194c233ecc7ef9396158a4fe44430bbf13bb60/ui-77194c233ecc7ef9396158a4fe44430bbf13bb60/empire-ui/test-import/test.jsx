import React from 'react';
import { Button } from '@empireui/components';

function TestComponent() {
  return (
    <div>
      <h1>Testing Empire UI Component Import</h1>
      <Button>Click Me</Button>
    </div>
  );
}

export default TestComponent;
