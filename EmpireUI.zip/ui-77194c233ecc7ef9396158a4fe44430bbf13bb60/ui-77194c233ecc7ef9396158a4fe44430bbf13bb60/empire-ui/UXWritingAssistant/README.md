# UXWritingAssistant Component

## 📋 Description

**UXWritingAssistant** is an AI-powered UI component designed for frontend developers and designers. It allows you to instantly improve button labels, tooltips, headers, and other UI text using OpenAI’s GPT model.

## ✨ Features

- Accepts any UI string as input
- Uses GPT-4 to suggest clearer, friendlier, or more accessible alternatives
- Useful in design systems, prototyping tools, or admin dashboards

## 📦 Props

| Prop         | Type     | Description |
|--------------|----------|-------------|
| `originalText` | `string` | The original UI label to improve |
| `apiKey`     | `string` | Your OpenAI API Key |

## 🚀 Example Usage

```tsx
import { UXWritingAssistant } from './UXWritingAssistant';

<UXWritingAssistant 
  originalText="Submit" 
  apiKey="your-openai-key" 
/>
