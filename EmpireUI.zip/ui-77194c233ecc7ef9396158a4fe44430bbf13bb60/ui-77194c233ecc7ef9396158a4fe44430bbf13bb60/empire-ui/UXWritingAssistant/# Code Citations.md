# Code Citations

## License: MIT
https://github.com/acrylic-style/homemade-copilot-for-cli/tree/299fddcabf79681e504c12f9687456a72438932f/app.mjs

```
api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(
```


## License: MIT
https://github.com/daveonHMD/ChatGPT-Chrome-Extension/tree/d69bcf22dfda625a8c36a093726a60666927bb36/html.js

```
response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json
```

