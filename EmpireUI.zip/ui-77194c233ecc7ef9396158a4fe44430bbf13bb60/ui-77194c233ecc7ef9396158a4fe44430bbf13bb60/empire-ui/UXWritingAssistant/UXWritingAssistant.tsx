import React, { useState } from 'react';

interface UXWritingAssistantProps {
  originalText: string;
  apiKey: string;
}

export const UXWritingAssistant: React.FC<UXWritingAssistantProps> = ({ originalText, apiKey }) => {
  const [suggestion, setSuggestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getSuggestion = async () => {
    setLoading(true);
    setSuggestion('');
    setError(null);
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: 'You are a helpful UX writer who improves UI copy for clarity and accessibility.',
            },
            {
              role: 'user',
              content: `Improve this UI text: "${originalText}"`,
            },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      const newText = data.choices?.[0]?.message?.content || 'No suggestion.';
      setSuggestion(newText);
    } catch (err: any) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 border rounded-md shadow-sm w-full max-w-xl bg-white">
      <p className="text-sm text-gray-700 mb-2">Original: <strong>{originalText}</strong></p>
      <button
        onClick={getSuggestion}
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
        disabled={loading}
      >
        {loading ? 'Thinking...' : 'Improve UX Copy'}
      </button>

      {error && (
        <div className="mt-4">
          <p className="text-xs text-red-600 mb-1">Error: {error}</p>
        </div>
      )}

      {suggestion && (
        <div className="mt-4">
          <p className="text-xs text-gray-600 mb-1">Suggestion:</p>
          <p className="text-green-700 font-semibold">{suggestion}</p>
        </div>
      )}
    </div>
  );
};
