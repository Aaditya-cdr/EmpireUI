import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";

// Export fonts
export { GeistSans, GeistMono };
