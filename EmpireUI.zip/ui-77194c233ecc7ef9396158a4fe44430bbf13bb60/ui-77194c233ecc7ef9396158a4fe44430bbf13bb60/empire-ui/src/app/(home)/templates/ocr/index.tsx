export { default as OcrTemplate } from './ocrTemplate';
