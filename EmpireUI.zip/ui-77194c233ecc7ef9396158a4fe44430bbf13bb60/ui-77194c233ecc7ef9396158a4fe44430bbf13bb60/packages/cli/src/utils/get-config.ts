import path from "path";
import fs from "fs-extra";
import { Config } from "../types";
import { logger } from "./logger";

export async function getConfig(): Promise<Config> {
  const configPath = path.join(process.cwd(), "components.json");

  if (!(await fs.exists(configPath))) {
    throw new Error("No components.json found. Run `empire-ui init` first.");
  }

  const config = (await fs.readJSON(configPath)) as Config;
  return config;
}

export async function validateConfig(config: Config) {
  // Validate the config has required fields
  const requiredFields: (keyof Config)[] = ["style", "tailwind", "aliases"];

  for (const field of requiredFields) {
    if (!config[field]) {
      throw new Error(`Missing required field: ${field} in components.json`);
    }
  }

  // Create required directories and files if they don't exist
  const tailwindConfig = path.join(process.cwd(), config.tailwind.config);
  const tailwindCss = path.join(process.cwd(), config.tailwind.css);
  const tailwindCssDir = path.dirname(tailwindCss);

  // Create all required directories
  await fs.ensureDir(tailwindCssDir);
  await fs.ensureDir(path.join(process.cwd(), config.aliases.components, "ui"));
  await fs.ensureDir(path.join(process.cwd(), config.aliases.utils));
  await fs.ensureDir(path.join(process.cwd(), "app")); // Ensure app directory exists

  // Create tailwind.config.js if it doesn't exist
  if (!(await fs.exists(tailwindConfig))) {
    const tailwindConfigContent = `/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}`;
    await fs.writeFile(tailwindConfig, tailwindConfigContent);
    logger.success(`Created ${config.tailwind.config}`);
  }

  // Create globals.css if it doesn't exist
  if (!(await fs.exists(tailwindCss))) {
    const globalsCssContent = `@tailwind base;
@tailwind components;
@tailwind utilities;
 
@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    --primary: 222.2 47.4% 11.2%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96.1%;
    --secondary-foreground: 222.2 47.4% 11.2%;
    --muted: 210 40% 96.1%;
    --muted-foreground: 215.4 16.3% 46.9%;
    --accent: 210 40% 96.1%;
    --accent-foreground: 222.2 47.4% 11.2%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 222.2 84% 4.9%;
    --radius: 0.5rem;
  }
 
  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 210 40% 98%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 212.7 26.8% 83.9%;
  }
}
 
@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}`;
    await fs.writeFile(tailwindCss, globalsCssContent);
    logger.success(`Created ${config.tailwind.css}`);
  }
}
